mysql={
    'host': 'localhost',
    'username': 'root',  #user="datarep"  
    'password': '',  #passwd="password"
    'database': "datarepresentation"
}