import mysql.connector

db = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  #user="datarep"  
  #passwd="password" 
  database="datarepresentation"
)

cursor = db.cursor()
sql="insert into film (title, director, released) values (%s,%s,%s)"
values = ('The Last of the Mohicans', 'Michael Mann', 1995)

cursor.execute(sql, values)

db.commit()
print("1 record inserted, ID:", cursor.lastrowid)