import mysql.connector

db = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  #user="datarep" 
  #passwd="password" 
  database="datarepresentation"
)

cursor = db.cursor()
sql="CREATE TABLE film (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(250), director varchar(250), released INT)"

cursor.execute(sql)