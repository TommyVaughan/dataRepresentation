mysql={
    'host': 'localhost',
    'user': 'root',  #user="datarep"  
    'password': '',  #passwd="password"
    'database': "datarepresentation"
}