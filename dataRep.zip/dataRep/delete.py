import mysql.connector

db = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  #user="datarep"
  #passwd="password" 
  database="datarepresentation"
)

cursor = db.cursor()
sql="delete from film where id = %s"
values = (7,)

cursor.execute(sql, values)

db.commit()
print("delete done")