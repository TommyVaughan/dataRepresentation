import mysql.connector

db = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  #user="datarep"
  #passwd="password" 
  database="datarepresentation"
)

cursor = db.cursor()
sql="update film set title= %s, director=%s, released=%s  where id = %s"
values = ('Alien','Ridley Scott', 1979, 1)

cursor.execute(sql, values)

db.commit()
print("update done")